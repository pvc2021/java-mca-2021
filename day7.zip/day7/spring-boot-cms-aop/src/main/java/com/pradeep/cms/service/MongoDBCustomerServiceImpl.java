package com.pradeep.cms.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.dao.CustomerRepository;
import com.pradeep.cms.domain.Customer;

@Service
public class MongoDBCustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository reposiotry;

	public MongoDBCustomerServiceImpl() {

		System.out.println("=============MongoDBCustomerServiceImpl  created=============");

	}

	@Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return reposiotry.save(customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		if (reposiotry.existsById(customer.getCustomerId())) {
			return reposiotry.save(customer) == customer;
		}

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		if (reposiotry.existsById(customerId)) {
			reposiotry.deleteById(customerId);
			return true;
		}

		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		
		//int r=100/0;
		
		// TODO Auto-generated method stub
		return reposiotry.findById(customerId).get();
	}

	@Override
	public Collection<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return reposiotry.findAll();
	}

}
