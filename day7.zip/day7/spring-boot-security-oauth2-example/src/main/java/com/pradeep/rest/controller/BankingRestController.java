package com.pradeep.rest.controller;

import java.security.Principal;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.spring.model.Account;
import com.pradeep.spring.service.AccountService;

@RequestMapping("/accounts")
@RestController
public class BankingRestController {
	@Autowired
	private AccountService accountService;

	public BankingRestController() {
		System.out.println("BankingRest App created....");
	}
	
	
	@GetMapping
	//@RequestMapping(value="/accounts",method=RequestMethod.GET)
	public List<Account> getAccountList(){
		System.out.println("In getAllAccountList....");
		return accountService.getAccountList();
	}
	
	
	@GetMapping("/{accno}")
	public Account getAccount(@PathVariable("accno") int accno){
		System.out.println("In getAccount....");
		return accountService.getAccount(accno);
	}
	
	

	@DeleteMapping("/{accno}")
	public List<Account> deleteAccount(@PathVariable("accno") int accno){
		System.out.println("In deleteAccount....");
		accountService.deleteAccount(accno);
		return accountService.getAccountList();
	}
	
	@PutMapping("/{accno}")
	public List<Account> updateAccount(@PathVariable("accno") int accno,@RequestBody Account account ){
		System.out.println("In updateAccount...."+account);
		accountService.updateAccount(account);
		return accountService.getAccountList();
	}
	
	
	@PostMapping
	public List<Account> addAccount(@RequestBody Account account ){
		System.out.println("In addAccount...."+account);
		accountService.addAccount(account);
		return accountService.getAccountList();
	}
	
	
	

}
