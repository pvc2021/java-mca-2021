package com.pradeep.spring.service;

import java.util.List;

import com.pradeep.spring.model.Account;

public interface AccountService {

	boolean addAccount(Account account);

	boolean updateAccount(Account account);

	boolean deleteAccount(int accno);

	Account getAccount(int accno);

	boolean deposit(int accno, double amount);

	boolean withdraw(int accno, double amount);
	
	List<Account> getAccountList();
	
	public boolean transferFund(int source, int destination, double amount);
	
	
}
