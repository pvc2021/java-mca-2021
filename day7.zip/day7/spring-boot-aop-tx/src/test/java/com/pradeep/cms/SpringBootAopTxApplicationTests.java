package com.pradeep.cms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAopTxApplicationTests {

	@Test
	void contextLoads() {
	}

}
