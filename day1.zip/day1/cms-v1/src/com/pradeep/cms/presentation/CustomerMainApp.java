package com.pradeep.cms.presentation;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.dao.MapCustomerDaoImpl;
import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;
import com.pradeep.cms.service.MapCustomerServiceImpl;

public class CustomerMainApp {
	
	
	
private CustomerService customerService;	


public CustomerMainApp() {
}

public void setCustomerService(CustomerService customerService) {
	this.customerService = customerService;
}



public void addCustomer(Customer customer) {
	if(customerService.saveCustomer(customer))
		System.out.println("Customer with id ["+customer.getCustomerId()+"] added successfully");
	else
		System.out.println("Problem in Inserting the Customer");
}

public void updateCustomer(Customer customer) {
	if(customerService.updateCustomer(customer))
		System.out.println("Customer with id ["+customer.getCustomerId()+"] updateed successfully");
	else
		System.out.println("Customer not found");
}

public void deleteCustomer(int customerId) {
	if(customerService.deleteCustomer(customerId))
		System.out.println("Customer with id ["+customerId+"] deleted successfully");
	else
		System.out.println("Customer not found");
}

	
public void showCustomer(int customerId) {
	
	Customer customer=customerService.findCustomer(customerId);
	
	if(customer!=null)
		System.out.println("Customer with id ["+customerId+"] Details \n\n"+customer);
	else
		System.out.println("Customer not found");
}


public void showAllCustomer() {
		System.out.println("All Customers\n=========================================");
	
		for(Customer c:customerService.findAllCustomers())
			System.out.println(c);
		
}

	
	
public CustomerMainApp(CustomerService customerService) {
	super();
	this.customerService = customerService;
}

public static void main(String[] args) {
	
MapCustomerDaoImpl mcdi=new MapCustomerDaoImpl();


//constructor-injection
MapCustomerServiceImpl mcsi=new MapCustomerServiceImpl(mcdi);
	
	
CustomerMainApp cma=new CustomerMainApp();
//setter-injection
cma.setCustomerService(mcsi);

cma.showAllCustomer();
	
}
}
