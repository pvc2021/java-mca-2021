package com.pradeep.cms.presentation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;

public class CustomerMainApp {

	private CustomerService customerService;

	public CustomerMainApp() {
		System.out.println("=============CustomerMainApp  created=============");
	}
		

	public CustomerMainApp(CustomerService customerService) {
		super();
		this.customerService = customerService;
		System.out.println("=============CustomerMainApp  parameterzed constructor============");
		
	}




	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
		
		System.out.println("=============CustomerMainApp  setCustomerService=============");
		
	}

	public void addCustomer(Customer customer) {
		if (customerService.saveCustomer(customer))
			System.out.println("Customer with id [" + customer.getCustomerId() + "] added successfully");
		else
			System.out.println("Problem in Inserting the Customer");
	}

	public void updateCustomer(Customer customer) {
		if (customerService.updateCustomer(customer))
			System.out.println("Customer with id [" + customer.getCustomerId() + "] updateed successfully");
		else
			System.out.println("Customer not found");
	}

	public void deleteCustomer(int customerId) {
		if (customerService.deleteCustomer(customerId))
			System.out.println("Customer with id [" + customerId + "] deleted successfully");
		else
			System.out.println("Customer not found");
	}

	public void showCustomer(int customerId) {

		Customer customer = customerService.findCustomer(customerId);

		if (customer != null)
			System.out.println("Customer with id [" + customerId + "] Details \n\n" + customer);
		else
			System.out.println("Customer not found");
	}

	public void showAllCustomer() {
		System.out.println("All Customers\n=========================================");

		for (Customer c : customerService.findAllCustomers())
			System.out.println(c);

	}

	
	public void init() {
		System.out.println("================CustomerMainApp  initialized============");
	}
	
	
	public void destroy() {
		System.out.println("================CustomerMainApp  destroyed============");
	}
	

	public static void main(String[] args) {

	//create a core container

		//XmlBeanFactory c=new XmlBeanFactory(new ClassPathResource("beans.xml"));
		ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("Spring Container created.....");
		
		
		//get bean from container
		 //If only one bean of that type is available
		
		 //CustomerMainApp cma=c.getBean(CustomerMainApp.class);
		
		 //If multiple bean of that type is available
		CustomerMainApp cma=(CustomerMainApp)c.getBean("customerMainApp");
		CustomerMainApp cma1=(CustomerMainApp)c.getBean("customerMainApp");
		CustomerMainApp cma2=(CustomerMainApp)c.getBean("customerMainApp");
				 
		
		
		cma.showAllCustomer();
			
		//shutdown the container
		c.registerShutdownHook();
		
		
		System.out.println(cma);
		System.out.println(cma1);
		System.out.println(cma2);
		
		
	}
}
