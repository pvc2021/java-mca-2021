package com.pradeep.cms.spring;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;


@RequestMapping("/spring")
@Controller
public class SpringController {
	
	
	public SpringController() {
	System.out.println("......SpringController Created....");
	}

	
	
	@RequestMapping("/hello")
	public String hello() {
		return "hello";
	}
	
	
	@RequestMapping("/welcome")
	public String welcome() {
		return "welcome";
	}
	
	
	@RequestMapping("/today")
	public ModelAndView today() {
		return new ModelAndView("today", "message", new Date());
	}
	
	@RequestMapping(value="/greet")
	@ResponseBody
	public String greet() {
		return "Hi all,Hope You are enjoying the session";
	}
		
}
