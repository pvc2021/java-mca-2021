package com.pradeep;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Demo {
public static void main(String[] args) {
	
	BCryptPasswordEncoder e=new BCryptPasswordEncoder();
	
	System.out.println(e.encode("RAM"));
	System.out.println(e.encode("RAHIM"));
	System.out.println(e.encode("DAVID"));
	
	
	
}
}
