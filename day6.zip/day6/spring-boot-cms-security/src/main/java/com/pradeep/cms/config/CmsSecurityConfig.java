package com.pradeep.cms.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class CmsSecurityConfig extends WebSecurityConfigurerAdapter {

	
	@Autowired
	private DataSource dataSource;
	
	
	
	public CmsSecurityConfig() {

		System.out.println("===CmsSecurityConfig created==========");
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		// super.configure(auth); //use default username and password

		/*auth.inMemoryAuthentication()
		           .withUser("RAM").password("{noop}RAM").roles("ADMIN","STUDENT").and()
		           .withUser("RAHIM").password("{noop}RAHIM").roles("STUDENT").and()
		           .withUser("DAVID").password("{noop}DAVID").roles("TEACHER");
		           
		           */
		
		auth.jdbcAuthentication()
		    .passwordEncoder(new BCryptPasswordEncoder())
		    .dataSource(dataSource);

	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.authorizeRequests()
		.antMatchers("/rest/*").denyAll()
		.antMatchers("/rest/*").permitAll()
		  		.antMatchers("/spring/customers").hasRole("ADMIN")
				.antMatchers("/spring/welcome","/spring/today").hasRole("TEACHER")
				.antMatchers("/spring/hello","/spring/greet").hasAnyRole("ADMIN","TEACHER")
				.anyRequest()
		        .authenticated()
		        .and()
				.formLogin();// Form Based
		 
				//.httpBasic();// Basic Auth

	}
}
