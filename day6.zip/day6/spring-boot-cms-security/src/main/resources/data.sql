insert into users(username, password, enabled)values('RAM','$2a$10$ge2ybXdrHWmY6qNWOkCaze2jAgTfeTovMsbUciUJCzIcfG/x.YGZi',true);
insert into authorities(username,authority)values('RAM','ROLE_ADMIN');
 
insert into users(username, password, enabled)values('RAHIM','$2a$10$ZuVLPUbpOc7Bxeu5GRdD4.XH0XWl4H6103a9OqNP58PTX/zqeGe1W',true);
insert into authorities(username,authority)values('RAHIM','ROLE_STUDENT');

insert into users(username, password, enabled)values('DAVID','$2a$10$9T6gPdQEug.dtrOorCwlVeQLd14OzZv649bGnl2fv3/jl4NZVc22u',true);
insert into authorities(username,authority)values('DAVID','ROLE_TEACHER');

