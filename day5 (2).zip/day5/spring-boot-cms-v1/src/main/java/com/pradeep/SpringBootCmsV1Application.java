package com.pradeep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;



@SpringBootApplication
public class SpringBootCmsV1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCmsV1Application.class, args);
	}

}
